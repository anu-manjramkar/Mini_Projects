
function validate()
{

    let f = false;
        // username-validation
    let name = $(".name-field").val();
    if (name == '' || name == undefined) 
    {  
        
        $(".name-field-msg").html("Name is required !!").addClass("text-danger");
        
        f = false;

    }

    else
    {
        $(".name-field-msg").html("").removeClass("text-danger").addClass("text-success");
        
        f = true;
    

    }

    // email-validation

    let email = $(".email-field").val();
    let exp = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (email == '' || email == undefined) 
    {  
        
        $(".email-field-msg").html("Email is required !!").addClass("text-danger");
        
        f = false;
 
    }

    else if(exp.test(email)==false)
    {
        $(".email-field-msg").html("Invalid Email, Email must contain @ , . (example@gmail.com) !!").addClass("text-danger");
        
        f = false;
    }

    else
    {
          $(".email-field-msg").html("").removeClass("text-danger").addClass("text-success");
        
        f = true;

    }

    // password validation

    let paswd = $(".password-field").val();
    let psd = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/

    if (paswd == '' || paswd == undefined) 
    {  
        
        $(".password-field-msg").html("Password is required !!").addClass("text-danger");
        
        f = false;
 
    }

    else if(psd.test(paswd)==false)
    {
        $(".password-field-msg").html("Invalid Password, It must contain atleast 1 Uppercase char , 1 Lowercase char ,1 digit and length must be 6 to 10 !!").addClass("text-danger");
        
        f = false;
    }
    
    else
    {
          $(".password-field-msg").html("").removeClass("text-danger").addClass("text-success");
        
        f = true;

    }
    
    //  Confirm-password-validation

    
    let pst = $(".con-password-field ").val();
    
    if (paswd == pst && psd.test(paswd)==true ) 
    {
        
         $(".con-password-field-msg").html("Password Matched").removeClass("text-danger").addClass("text-success");
        
        f = true;
    }
    else if(psd.test(paswd)==true && pst!=paswd && pst!='')
    {
        $(".con-password-field-msg").html("Password did not match").addClass("text-danger");
        
        f = false;

    }


    // phone-number-validation

    let ph=$(".phone-field ").val();
         
   if (ph == '' || ph == undefined) 
    {  
        
        $(".phone-field-msg").html("Phone No is required !!").addClass("text-danger");
        
        f = false;

    }

   else if (ph.length == 10)
   {
       f = true;
       $(".phone-field-msg").html("").removeClass("text-danger").addClass("text-success");
       
    }
    
   else
   {
        $(".phone-field-msg").html("Invalid Phone No , it must be of 10 digits!!").addClass("text-danger");
        
        f = false;
       
    }

    return f;
}



