window.addEventListener('DOMContentLoaded',()=>{
 let details=[];
 details.push({username:"aditya",password:"Aditya@123"});
 details.push({username:"adinath",password:"Adinath@123"});
 details.push({username:"anant",password:"Anant@123"});
 details.push({username:"anurag",password:"Anurag@123"});

    let t1=document.querySelector('#user');
    let t2=document.querySelector('#password');
    let lgnbtn=document.querySelector('#lgnbtn');
    function check(user,pass){
        console.log("Inside Check Function");
        let result={ status:false,username:"",password:""};
        for(let i=0;i<details.length;i++){
            if(details[i].username==user&&details[i].password==pass){
                result.status=true;
                result.username=details[i].username;
                result.password=details[i].password;
                break;
            }
        }
        return result;
    }
    const box=document.querySelector('#box');
   box.addEventListener('click',()=>{
      if(box.checked==true){
        console.log("Inside If Condition");
        let result1=check(t1.value,t2.value);
            if(result1.status){
                lgnbtn.disabled=false;
                
            }
            else{
                let msg=document.querySelector('#msg');
                msg.classList.add("msg1");
                msg.innerHTML="Invalid Username/Password";
            }

       }
       else{
        lgnbtn.disabled=true;
        msg.innerHTML="";
       }

   });
   lgnbtn.addEventListener('click',()=>{
    alert("Successfully Logged In");
   });
});